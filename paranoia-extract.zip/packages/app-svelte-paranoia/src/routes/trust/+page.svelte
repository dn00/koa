<div class="page-container">
  <h1>TRUST & COVERT OPS</h1>
  <p>Suspicion Level: 27%</p>
</div>
<style>
  .page-container { padding: var(--spacing-md); }
</style>
