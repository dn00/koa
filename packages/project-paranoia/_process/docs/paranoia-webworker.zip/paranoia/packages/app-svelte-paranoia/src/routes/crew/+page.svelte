<div class="page-container">
  <h1>CREW MANIFEST</h1>
  <p>Status: 4/4 Active</p>
</div>
<style>
  .page-container { padding: var(--spacing-md); }
</style>
