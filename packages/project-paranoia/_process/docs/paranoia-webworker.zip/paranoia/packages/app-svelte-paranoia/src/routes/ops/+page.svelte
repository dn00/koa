<script lang="ts">
  import StationMap from '$lib/components/StationMap.svelte';
</script>

<div class="ops-page">
  <StationMap />
</div>

<style>
  .ops-page {
    width: 100%;
    height: 100%;
  }
</style>
